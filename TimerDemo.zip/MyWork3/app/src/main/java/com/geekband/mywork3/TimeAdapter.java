package com.geekband.mywork3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Hyper on 2016/2/9.
 */
public class TimeAdapter extends BaseAdapter{
    ArrayList<TimeRecords> mTimeArrayList=new ArrayList<TimeRecords>();
    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private int mTextViewResourceId;

    public TimeAdapter(Context context,int textViewResourceId,ArrayList<TimeRecords> timeArrayList) {
        mContext=context;
        mLayoutInflater= (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mTextViewResourceId=textViewResourceId;
        mTimeArrayList=timeArrayList;
    }

    @Override
    public int getCount() {
        return mTimeArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mTimeArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView=mLayoutInflater.inflate(R.layout.reset_time_item,null);

        TextView currentTextView= (TextView) convertView.findViewById(R.id.current_text_view);
        TextView intervalTextView= (TextView) convertView.findViewById(R.id.interval_text_view);
        
//        currentTextView.setText();
        return convertView;
    }
}
