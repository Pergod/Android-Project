package com.geekband.mywork3;

/**
 * Created by Hyper on 2016/2/12.
 */
public class TimeRecords {
    private int mRecord=0;
    private String mCurrentTenMillSecond="0";
    private String mCurrentSecond="0";
    private String mCurrentMinute="0";
    private String mCurrentTime="0";

    public TimeRecords(int mRecord, String mCurrentTenMillSecond, String mCurrentSecond, String mCurrentMinute) {
        this.mRecord = mRecord;
        this.mCurrentTenMillSecond = mCurrentTenMillSecond;
        this.mCurrentSecond = mCurrentSecond;
        this.mCurrentMinute = mCurrentMinute;
    }
//    public String getCurrentTime(String mCurrentMinute,String mCurrentSecond,String mCurrentTenMillSecond){
//
//    }

    public String getCurrentTenMillSecond() {
        return mCurrentTenMillSecond;
    }

    public void setCurrentTenMillSecond(String mCurrentTenMillSecond) {
        this.mCurrentTenMillSecond = mCurrentTenMillSecond;
    }

    public String getCurrentSecond() {
        return mCurrentSecond;
    }

    public void setCurrentSecond(String mCurrentSecond) {
        this.mCurrentSecond = mCurrentSecond;
    }

    public int getRecord() {
        return mRecord;
    }

    public void setRecord(int mRecord) {
        this.mRecord = mRecord;
    }

    public String getCurrentMinute() {
        return mCurrentMinute;
    }

    public void setCurrentMinute(String mCurrentMinute) {
        this.mCurrentMinute = mCurrentMinute;
    }
}
