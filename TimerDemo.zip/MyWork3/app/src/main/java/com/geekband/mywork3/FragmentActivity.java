package com.geekband.mywork3;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Created by Hyper on 2016/2/10.
 */
public class FragmentActivity extends Fragment implements View.OnClickListener{
    private static final String TAG =MainActivity.class.getSimpleName();

    public static final int SECOND_CODE = 888888;
    public static final int MINUTE_CODE = 666666;
    public static final int TENMILLSECOND_CODE = 999999;
    public static final double mDrawAngle=(1.0/60);

    private HandlerTime mHandlerSecond=new HandlerTime(this);
    private HandlerTime mHandlerMinute=new HandlerTime(this);
    private HandlerTime mHandlerTenMillSecond=new HandlerTime(this);

    private ImageButton mResetButton;
    private ImageButton mControllButton;

    private TextView mSecondTextView;
    private TextView mMinuteTextView;
    private TextView mTenMillSecondTextView;

    private  RoundProgressBar roundProgressBar;
    private double mPercent=(1.0/60);

    private int ResourceId=R.drawable.ic_pause;

    private Object object1=10;
    private Object object2=1000;
    private Object object3=1000;

    private String currentTenMillSecond;
    private String currentSecond;
    private String currentMinute;
    private int Record=0;

    private TimeRecords mTimeRecords;
    private ArrayList<TimeRecords> mTimeRecordsArrayList=new ArrayList<TimeRecords>();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_activity,container,false);
        mSecondTextView = (TextView)view.findViewById(R.id.second_text_view);
        mMinuteTextView= (TextView)view.findViewById(R.id.minute_text_view);
        mTenMillSecondTextView=(TextView)view.findViewById(R.id.tenmillsecond_text_view);

        //重置按钮点击事件
        mResetButton= (ImageButton) view.findViewById(R.id.reset_button);
        mResetButton.setOnClickListener(this);

        //开始，暂停按钮点击事件
        mControllButton= (ImageButton) view.findViewById(R.id.controll_button);
        mControllButton.setOnClickListener(this);


        //获取重置间隔时间
//        TimeAdapter timeAdapter=new TimeAdapter(FragmentActivity.this,R.layout.reset_time_item,mTimeRecordsArrayList);
        ListView listView=(ListView)view.findViewById(R.id.reset_list_view);
//        listView.setAdapter(timeAdapter);

        //获取自定义环形进度条
        roundProgressBar=new RoundProgressBar(view.getContext());
        roundProgressBar=(RoundProgressBar)view.findViewById(R.id.round_progress_bar);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    private TextView getmSecondTextView() {
        return mSecondTextView;
    }

    public TextView getmMinuteTextView() {
        return mMinuteTextView;
    }

    private TextView getmTenMillSecondTextView(){
        return mTenMillSecondTextView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            //判断开始or暂停按钮
            case R.id.controll_button:

                //点击之后 暂停
                if (ResourceId==R.drawable.ic_play){
                    ResourceId=R.drawable.ic_pause;
                    mControllButton.setImageResource(ResourceId);

                    mHandlerTenMillSecond.removeMessages(TENMILLSECOND_CODE);
                    mHandlerSecond.removeMessages(SECOND_CODE);
                    mHandlerMinute.removeMessages(MINUTE_CODE);
                    break;
                }

                //点击之后 开始
                else if(ResourceId==R.drawable.ic_pause){
                    ResourceId=R.drawable.ic_play;
                    mControllButton.setImageResource(ResourceId);

                    //发送毫秒消息
                    Message TenMillSecondMessage=mHandlerTenMillSecond.obtainMessage();
                    TenMillSecondMessage.arg1=0;
                    TenMillSecondMessage.arg2=0;
                    TenMillSecondMessage.obj=object1;
                    TenMillSecondMessage.what=TENMILLSECOND_CODE;
                    mHandlerTenMillSecond.sendMessageDelayed(TenMillSecondMessage, 10);

                    //发送消息秒
                    Message SecondMessage= mHandlerSecond.obtainMessage();
                    SecondMessage.arg1=0;
                    SecondMessage.arg2=0;
                    SecondMessage.obj=object2;
                    SecondMessage.what= SECOND_CODE;
                    mHandlerSecond.sendMessageDelayed(SecondMessage, 1000);

                    //发送消息分钟
                    Message MinuteMessage=mHandlerMinute.obtainMessage();
                    MinuteMessage.arg2=0;
                    MinuteMessage.arg1=0;
                    MinuteMessage.obj=object3;
                    MinuteMessage.what=MINUTE_CODE;
                    mHandlerMinute.sendMessageDelayed(MinuteMessage, 60 * 1000);
                    break;
                }

            //重置按钮
            case R.id.reset_button:
                ResourceId=R.drawable.ic_pause;
                mControllButton.setImageResource(ResourceId);

                Record++;
                currentTenMillSecond=(String)mTenMillSecondTextView.getText();
                currentSecond= (String) mSecondTextView.getText();
                currentMinute= (String) mMinuteTextView.getText();

                mTimeRecords=new TimeRecords(Record,currentTenMillSecond,currentSecond,currentMinute);

                mTenMillSecondTextView.setText("0");
                mSecondTextView.setText("0");
                mMinuteTextView.setText("0");

                mHandlerTenMillSecond.removeMessages(TENMILLSECOND_CODE);
                mHandlerSecond.removeMessages(SECOND_CODE);
                mHandlerMinute.removeMessages(MINUTE_CODE);

                object1=10;
                object2=1000;
                object3=1000;
                mPercent=(1.0/60);
                roundProgressBar.setPercent(0);
                break;
        }
    }

    //外部类
    public  class  HandlerTime extends Handler {
        public final WeakReference<FragmentActivity> mFragmentActivityWeakReference;
        public HandlerTime(FragmentActivity activity) {
            mFragmentActivityWeakReference=new WeakReference<FragmentActivity>(activity);
        }

        //接收消息
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            FragmentActivity fragmentActivity=mFragmentActivityWeakReference.get();
            switch (msg.what){

                case TENMILLSECOND_CODE:
                    int tenmillsecond= (int) msg.obj;
                    fragmentActivity.getmTenMillSecondTextView().setText(String.valueOf(tenmillsecond/10));
                    msg=Message.obtain();
                    msg.arg2=0;
                    msg.arg1=0;
                    msg.what=TENMILLSECOND_CODE;
                    msg.obj=tenmillsecond+10;
                    object1=msg.obj;
                    if (tenmillsecond<99*10){
                        sendMessageDelayed(msg, 10);
                    }
                    else {
                        msg.obj=0;
                        sendMessageDelayed(msg, 10);
                    }
                    break;

                case SECOND_CODE:
                    int second= (int) msg.obj;
                    fragmentActivity.getmSecondTextView().setText(String.valueOf(second/1000));
                    msg=Message.obtain();
                    msg.arg1=0;
                    msg.arg2=0;
                    msg.what= SECOND_CODE;
                    msg.obj=second+1000;
                    object2=msg.obj;
                    if (second <59000) {
                        sendMessageDelayed(msg,1000);
                        roundProgressBar.setPercent(mPercent);
                        mPercent+=mDrawAngle;
                    }
                    else {
                        mPercent+=mDrawAngle;
                        msg.obj=0;
                        sendMessageDelayed(msg, 1000);
                        roundProgressBar.setPercent(mPercent);
                        mPercent=(1.0/60);
                    }
                    break;

                case MINUTE_CODE:
                    int minute= (int) msg.obj;
                    fragmentActivity.getmMinuteTextView().setText(String.valueOf(minute/1000));
                    msg=Message.obtain();
                    msg.arg2=0;
                    msg.arg1=0;
                    msg.what=MINUTE_CODE;
                    msg.obj=minute+1000;
                    object3=msg.obj;
                    if (minute<=59*1000){
                        sendMessageDelayed(msg,60*1000);
                    }
                    else {
                        msg.obj=0;
                        sendMessageDelayed(msg,60*1000);
                    }
                    break;

            }
        }
    }
}
