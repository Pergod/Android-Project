package com.geekband.mywork3;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;

import java.util.Properties;

/**
 * Created by Hyper on 2016/2/5.
 */

/**
 * 环形进度条
 *
 */
public class RoundProgressBar extends View {
    private Paint mPaint;
    private int mRoundColor;
    private int mProgressRoundColor;
    private float mRoundWidth;
    private int mCircleStyle;
    private int mInitProgress;
    private int mMaxProgress;
    private int mProgress;
    private int CenterX;
    private int CenterY;
    private int Radius;

    public void setPercent(double mPercent) {
        this.mPercent = mPercent;
    }

    private double mPercent;
    private RectF mOval;

    private Handler mHandler;

    public RoundProgressBar(Context context) {
        this(context, null);
    }

    public RoundProgressBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RoundProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context,AttributeSet attrs) {
        mPaint=new Paint();
        mOval=new RectF();
        mHandler=new Handler();
        TypedArray typedArray=context.obtainStyledAttributes(attrs,R.styleable.RoundProgressBar);
        mRoundColor=typedArray.getColor(R.styleable.RoundProgressBar_RoundColor,Color.WHITE);
        mProgressRoundColor=typedArray.getColor(R.styleable.RoundProgressBar_ProgressRoundColor, Color.RED);
        mRoundWidth=typedArray.getDimension(R.styleable.RoundProgressBar_RoundWidth, 10.0f);
        mCircleStyle=typedArray.getInt(R.styleable.RoundProgressBar_CircleStyle, 0);
        mInitProgress=typedArray.getInt(R.styleable.RoundProgressBar_InitProgress,0);
        mMaxProgress=typedArray.getInt(R.styleable.RoundProgressBar_MaxProgress,100);
        mProgress=typedArray.getInt(R.styleable.RoundProgressBar_Progress,0);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        CenterX = getWidth() / 2;
        CenterY = getHeight() / 2;
        Radius = getWidth() / 2 - getWidth() / 6;

        //画一个圆环
        super.onDraw(canvas);
        mPaint.setColor(mRoundColor);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(mRoundWidth);
        mPaint.setAntiAlias(true);
        canvas.drawCircle(CenterX, CenterY, Radius, mPaint);

//        //画圆环进度，画弧
        mPaint.setColor(mProgressRoundColor);
        mPaint.setStrokeWidth(mRoundWidth);
        mPaint.setStrokeWidth(mRoundWidth);
        mPaint.setColor(mProgressRoundColor);

        mOval.left = CenterX - Radius;
        mOval.top = CenterY - Radius;
        mOval.right = CenterX + Radius;
        mOval.bottom = CenterY + Radius;

        canvas.drawArc(mOval, 270, (float) (mPercent*360), false, mPaint);
        invalidate();
    }
}
